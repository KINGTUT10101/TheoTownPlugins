function script:earlyInit ()
	disasterHeadlines = Array {
		"Citizens Call For Help As A Major Disaster Ravages The City",
		"PANIC! PANIC! There's A Disaster Afoot!",
		"Mayor, Your Citizens May Need Help! There's A Disaster Within The City!",
		"Emergency Alert: All Citizens Should Go To The Nearest Shelter Immediately!"
	}
	
--[[ (To Be Implemented)
	-- Temperature headlines
	hotHeadlines = Array {
		
	}
	
	coldHeadlines = Array {
		
	}
	
	-- Happiness headlines
	happyHeadlines = Array {
		
	}
	
	sadHeadlines = Array {
		
	}
]]--
end